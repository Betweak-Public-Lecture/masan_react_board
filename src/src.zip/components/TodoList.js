import React, {useState, useEffect} from 'react';

const defaultTodoList = [{
  title: '씻기',
  status: 'done'
}, {
  title: "밥먹기",
  status: "ready"
}]

export default function TodoList(props){
  const [todoList, setTodoList] = useState([]);
  console.log(todoList)

  // 컴포넌트가 rendering 후 계속해서 실행 되어줘야 하는 함수. (side Effect)
  useEffect(()=>{
    setTodoList(defaultTodoList);
  }, [])



  return (
    <div>
      <ul>
        <h1>TodoList</h1>
        
        {
          todoList.map(todo=>{
            return (
              <li>
                <div>
                  {todo.title}
                </div>
              </li>
            )
          })
        }

      </ul>
    </div>
  )
}