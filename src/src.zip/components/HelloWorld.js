import React from 'react'; // 있어야만 React 자체가 해당 파일이 React Component인지 이해함.

// const a = {
//   a: 1,
//   n:2
// }
export default function HelloWorld(){
  return (
    <div style={{textAlign: 'center'}} className="App-header">
      <h1>Hello World</h1>
      <p className="App-header">This is My First React Applicaton</p>
    </div>
  )
}


{/* <div></div> // HTML  < XML의 부분집합
<fffff></fffff> // XML */}



// "text-align" => textAlign
// "font-size" => fontSize

// export default HelloWorld;