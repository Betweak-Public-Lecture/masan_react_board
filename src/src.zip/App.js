import logo from './logo.svg';
import './App.css';
import HelloWorld from './components/HelloWorld';

import CaptionImage from './components/CaptionImage';
import Blink from './components/Blink';
import TodoList from './components/TodoList'

function App() {
  return (
    
    // <HelloWorld />

    <div>
      {/* <CaptionImage 
        imgUrl="https://newsimg.hankookilbo.com/cms/articlerelease/2019/04/29/201904291390027161_3.jpg" 
        caption="고양이"
        />
      <CaptionImage 
        imgUrl="https://newsimg.hankookilbo.com/cms/articlerelease/2019/04/29/201904291390027161_2.jpg" 
        caption="고양이"
        />
      <CaptionImage imgUrl='https://cdn.cvinfo.com/news/photo/201711/7409_11427_2949.png' caption="이건 트럭입니다." /> */}
      <div stye={{fontSize:60}}>
        <Blink text="이 문자는" rest="AAa" />
        {/* <Blink text="2초에 한번씩" /> */}
        {/* <Blink text="깜빡입니다." /> */}
        {/* <TodoList/> */}

      </div>

    </div>
  );
}

export default App;
